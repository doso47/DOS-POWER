DOS POWER - Android app
=======================

GitHub builds the app for you (free). You only do this once:

1. Go to https://github.com and sign up / sign in.
2. Click "+" (top right) > "New repository". Name it dos-power, choose Private, click "Create repository".
3. On the new page click "uploading an existing file".
4. Open this folder on your PC, select EVERYTHING inside it (including the .github folder)
   and drag it onto the GitHub page. Click "Commit changes".
5. Click the "Actions" tab. A build called "Build DOS POWER Android app" starts by itself.
   Wait about 5-8 minutes until it shows a green tick.
6. Open the repository's "Releases" (right side of the main page) on your phone,
   tap DOS-POWER.apk to download it, open it, and allow "Install unknown apps" when Android asks.

To update the app later: upload a new market_globe.py to the same repository.
GitHub builds a new APK automatically; install it over the old one.
