"""
Builds the phone version of DOS POWER (www/index.html) from market_globe.py.
Run:  python build_mobile.py
"""
import json
import os
import sys
import types

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.modules.setdefault("webview", types.ModuleType("webview"))  # not needed on phone
import market_globe as mg  # noqa: E402

MOBILE_HEAD = r"""<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<style>
/* ---------- phone layout ---------- */
html,body{height:auto;min-height:100%;overflow-x:hidden;overflow-y:auto;-webkit-tap-highlight-color:transparent}
body{padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}
#space{position:fixed}
#news,#news-ar,#news-kw{position:relative;top:auto;height:32px}
#news .lbl,#news-ar .lbl,#news-kw .lbl{padding:0 10px;font-size:11.5px}
.item{font-size:13px;padding:0 16px}
#news-ar .item{font-size:14px}
#stage{position:relative;height:58vh;min-height:360px;max-height:640px}
#clock{right:0;bottom:8px}
#clock .t{font-size:34px}
#clock .t span{font-size:16px}
#clock .d{font-size:11px}
#styles{right:0;bottom:80px;padding:0 10px;gap:5px}
#styles button{font-size:11px;padding:5px 9px}
.brand{font-size:19px;left:14px;top:12px;bottom:auto;letter-spacing:4px}
#sessions{position:relative;top:auto;left:auto;width:auto;margin:12px}
#panel{position:relative;top:auto;right:auto;bottom:auto;width:auto;margin:0 12px 28px;overflow:visible}
.plabel{font-size:10px}
</style>
"""

MOBILE_SHIM = r"""<script>
/* ---------- phone build: layout + replacements for the desktop (Python) parts ---------- */
window.IS_MOBILE=true;
(function(){
  const st=document.createElement('div'); st.id='stage';
  document.getElementById('news-kw').after(st);
  ['globe','solar','styles','clock'].forEach(id=>st.appendChild(document.getElementById(id)));
  st.appendChild(document.querySelector('.brand'));
  st.after(document.getElementById('sessions'));
  window.STAGE_EL=st;
})();

(function(){
  const FEEDS=__FEEDS__, FEEDS_AR=__FEEDS_AR__, FEEDS_KW=__FEEDS_KW__;
  const CACHE=5*60*1000, PER_FEED=8, cache={};
  const deco=document.createElement('textarea');
  const clean=t=>{ deco.innerHTML=String(t||'').replace(/<[^>]+>/g,''); return deco.value.trim(); };
  const child=(el,...names)=>{ for(const n of names) for(const c of el.children) if(c.localName===n) return c; return null; };

  function tagFor(title,def){
    const t=title.toLowerCase();
    if(/بيتكوين|بتكوين|كريبتو|المشفرة|الرقمية|إيثريوم|زيكاش/.test(t)) return 'CRYPTO';
    if(/ذهب|الذهب|المعادن النفيسة|الفضة/.test(t)) return 'GOLD';
    if(/نفط|النفط|برنت|الخام|أوبك|البرميل/.test(t)) return 'OIL';
    if(/bitcoin|btc|zcash|zec|crypto|ether|blockchain|stablecoin/.test(t)) return 'CRYPTO';
    if(/\bgold\b|bullion|xau|silver|precious/.test(t)) return 'GOLD';
    if(/\boil\b|crude|brent|wti|opec|barrel|gasoline/.test(t)) return 'OIL';
    return def;
  }
  function parse(xml,source,def){
    const doc=new DOMParser().parseFromString(xml,'text/xml');
    let nodes=[...doc.getElementsByTagName('item')];
    if(!nodes.length) nodes=[...doc.getElementsByTagName('entry')];
    const out=[];
    for(const it of nodes.slice(0,PER_FEED)){
      let title=clean((child(it,'title')||{}).textContent);
      if(!title) continue;
      const l=child(it,'link'); const link=l?(l.getAttribute('href')||l.textContent.trim()):'';
      let src=source; const se=child(it,'source');
      if(se&&se.textContent.trim()){ src=se.textContent.trim(); if(title.endsWith(' - '+src)) title=title.slice(0,-(' - '+src).length).trim(); }
      const d=child(it,'pubDate','updated','published'); const ms=d?Date.parse(d.textContent.trim()):NaN;
      out.push({title,link,ts:isNaN(ms)?0:ms/1000,source:src,tag:tagFor(title,def)});
    }
    return out;
  }
  async function one([source,url,tag]){
    try{
      const r=await fetch(url,{headers:{'User-Agent':'Mozilla/5.0 (Linux; Android 14) DOS-POWER/1.0',
        'Accept':'application/rss+xml, application/xml, text/xml, */*'}});
      return parse(await r.text(),source,tag);
    }catch(e){ return []; }
  }
  async function all(feeds,key){
    const c=cache[key];
    if(c&&c.items.length&&Date.now()-c.t<CACHE) return c.items;
    const res=await Promise.all(feeds.map(one));
    const seen=new Set(), items=[];
    res.flat().forEach(n=>{ const k=n.title.toLowerCase().slice(0,80); if(!seen.has(k)){ seen.add(k); items.push(n); } });
    const cut=Date.now()/1000-3*86400;
    const list=items.filter(n=>!n.ts||n.ts>cut).sort((a,b)=>b.ts-a.ts).slice(0,40);
    if(list.length) cache[key]={t:Date.now(),items:list};
    return (cache[key]||{items:[]}).items;
  }
  function store(k,v){ try{ if(v===undefined) return localStorage.getItem(k); localStorage.setItem(k,v); }catch(e){ return null; } }

  window.pywebview={api:{
    get_news:()=>all(FEEDS,'en'),
    get_news_ar:()=>all(FEEDS_AR,'ar'),
    get_news_kw:()=>all(FEEDS_KW,'kw').then(items=>items.map(n=>{
      if(/boursa|bourse|stock|shares|index|بورصة|البورصة|مؤشر|أسهم/i.test(n.title)) n.tag='BOURSA';
      else if(!['CRYPTO','GOLD','OIL'].includes(n.tag)) n.tag='KUWAIT';
      return n;
    })),
    open_link:url=>{ if(/^https?:\/\//.test(url)) window.open(url,'_blank'); return Promise.resolve(true); },
    load_style:()=>Promise.resolve(store('dos-style')||'solar'),
    save_style:n=>{ store('dos-style',String(n)); return Promise.resolve(true); }
  }};
})();
</script>
"""


def build():
    symbols = [{"name": n, "symbol": s} for n, s in mg.SYMBOLS]
    page = mg.HTML.replace("__SYMBOLS__", json.dumps(symbols))
    shim = (MOBILE_SHIM
            .replace("__FEEDS__", json.dumps(mg.FEEDS, ensure_ascii=False))
            .replace("__FEEDS_AR__", json.dumps(mg.FEEDS_AR, ensure_ascii=False))
            .replace("__FEEDS_KW__", json.dumps(mg.FEEDS_KW, ensure_ascii=False)))
    assert page.count("</style></head>") == 1
    page = page.replace("</style></head>", "</style>\n" + MOBILE_HEAD + "</head>")
    marker = '<script src="https://unpkg.com/globe.gl"></script>'
    assert page.count(marker) == 1
    page = page.replace(marker, shim + marker)
    out = os.path.join(HERE, "www")
    os.makedirs(out, exist_ok=True)
    with open(os.path.join(out, "index.html"), "w", encoding="utf-8") as f:
        f.write(page)
    print("Built www/index.html")


if __name__ == "__main__":
    build()
