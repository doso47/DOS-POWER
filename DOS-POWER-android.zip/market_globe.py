"""
Market Globe - desktop price board with a rotating 3D world.
Prices and mini charts come live from TradingView.

Run:  pip install -r requirements.txt
      python market_globe.py
"""
import json
import os
import re
import tempfile
import threading
import time
import webbrowser
import html as htmllib
import urllib.request
import xml.etree.ElementTree as ET
from email.utils import parsedate_to_datetime

import webview

# (card name, TradingView symbol)  - change or add symbols here
SYMBOLS = [
    ("Bitcoin", "BITSTAMP:BTCUSD"),
    ("Zcash",   "BINANCE:ZECUSDT"),
    ("Gold",    "OANDA:XAUUSD"),
    ("UK Oil",  "TVC:UKOIL"),
    ("US Oil",  "TVC:USOIL"),
]

HTML = r"""<!doctype html>
<html><head><meta charset="utf-8">
<title>DOS POWER</title>
<style>
:root{--bg:#05070d;--card:rgba(14,20,34,.78);--line:rgba(120,150,200,.18);
--text:#e6edf7;--muted:#8a97ad;--accent:#4f7cff}
html,body{margin:0;height:100%;background:var(--bg);color:var(--text);
font-family:"Segoe UI",system-ui,-apple-system,sans-serif;overflow:hidden;user-select:none}
#space{position:absolute;inset:0;width:100%;height:100%;display:block}
#globe{position:absolute;left:0;top:0}
#solar{position:absolute;left:0;top:0;overflow:hidden;display:none}
#solar canvas{display:block}
.plabel{position:absolute;left:0;top:0;font-size:11.5px;letter-spacing:1.5px;color:#d8f6ff;white-space:nowrap;
pointer-events:none;text-shadow:0 0 6px #22d3ee,0 1px 4px #000;will-change:transform}
.plabel.sun{color:#ffe7a8;text-shadow:0 0 8px #f59e0b,0 1px 4px #000;font-weight:600}
#panel{position:absolute;top:128px;right:14px;bottom:14px;width:340px;display:flex;
flex-direction:column;gap:10px;overflow-y:auto}
header{display:flex;align-items:center;justify-content:space-between;padding:2px}
.title{font-weight:600;letter-spacing:2px;font-size:13px;color:var(--muted)}
.ranges button{background:transparent;border:1px solid var(--line);color:var(--muted);
padding:4px 9px;border-radius:6px;cursor:pointer;font:inherit;font-size:12px;margin-left:4px}
.ranges button.on{color:var(--text);border-color:var(--accent);background:rgba(79,124,255,.15)}
#cards{display:flex;flex-direction:column;gap:10px}
.card{background:var(--card);border:1px solid var(--line);border-radius:12px;
height:128px;overflow:hidden;backdrop-filter:blur(8px)}
.tradingview-widget-container,.tradingview-widget-container__widget{height:100%;width:100%}
footer{font-size:11px;color:var(--muted);text-align:right;padding-right:2px}
#sessions{position:absolute;top:128px;left:14px;width:330px;background:var(--card);
border:1px solid var(--line);border-radius:12px;padding:10px 12px;backdrop-filter:blur(8px)}
#sessions .title{display:block;margin-bottom:6px}
.mkt{display:grid;grid-template-columns:12px 1fr auto;column-gap:8px;align-items:center;
padding:4px 0;border-top:1px solid var(--line)}
.mkt:first-of-type{border-top:none}
.dot{width:9px;height:9px;border-radius:50%}
.mkt.open .dot{background:#22c55e;box-shadow:0 0 8px #22c55e}
.mkt.closed .dot{background:#ef4444;box-shadow:0 0 6px rgba(239,68,68,.6)}
.nm{font-size:13.5px;font-weight:600}
.nm small{font-weight:400;color:var(--muted);font-size:11px;margin-left:4px}
.tm{font-size:13px;font-variant-numeric:tabular-nums;color:var(--muted)}
.st{grid-column:2 / 4;font-size:11.5px;font-variant-numeric:tabular-nums}
#sessions .title small{letter-spacing:0;font-weight:400;opacity:.8}
#styles{position:absolute;bottom:100px;left:0;right:370px;display:flex;justify-content:center;
flex-wrap:wrap;gap:6px;padding:0 16px}
#styles button{background:rgba(14,20,34,.7);border:1px solid var(--line);color:var(--muted);
padding:5px 11px;border-radius:999px;cursor:pointer;font:inherit;font-size:12px;backdrop-filter:blur(6px)}
#styles button:hover{color:var(--text)}
#styles button.on{color:#fff;border-color:#3b9cff;background:rgba(59,156,255,.22)}
#news,#news-ar,#news-kw{position:absolute;top:0;left:0;right:0;height:38px;display:flex;align-items:center;
background:rgba(4,10,22,.88);border-bottom:1px solid rgba(34,211,238,.35);
box-shadow:0 0 18px rgba(34,211,238,.15);z-index:5;overflow:hidden}
#news .lbl,#news-ar .lbl,#news-kw .lbl{flex:none;height:100%;display:flex;align-items:center;padding:0 14px;font-weight:700;
letter-spacing:3px;font-size:13px;color:#e6fdff;background:rgba(34,211,238,.12);
border-right:1px solid rgba(34,211,238,.35);text-shadow:0 0 6px #22d3ee,0 0 14px #22d3ee}
#news .lbl i,#news-ar .lbl i,#news-kw .lbl i{width:8px;height:8px;border-radius:50%;background:#ef4444;margin-right:8px;
box-shadow:0 0 8px #ef4444;animation:blink 1.2s infinite}
@keyframes blink{50%{opacity:.25}}
#news .vp,#news-ar .vp,#news-kw .vp{flex:1;overflow:hidden;height:100%;position:relative;
mask-image:linear-gradient(90deg,transparent,#000 3%,#000 97%,transparent)}
#news .track,#news-ar .track,#news-kw .track{position:absolute;top:0;left:0;height:100%;display:flex;align-items:center;
white-space:nowrap;will-change:transform;animation:ticker var(--dur,120s) linear infinite}
#news:hover .track,#news-ar:hover .track,#news-kw:hover .track{animation-play-state:paused}
@keyframes ticker{from{transform:translateX(0)}to{transform:translateX(-50%)}}
.item{display:inline-flex;align-items:center;gap:8px;padding:0 22px;font-size:14px;color:#e6edf7;cursor:pointer}
.item:hover .h{color:#a5f3fc;text-decoration:underline}
.item .tag{font-size:10.5px;font-weight:700;letter-spacing:1px;padding:2px 7px;border-radius:4px}
.tag.CRYPTO{background:rgba(247,147,26,.18);color:#f7931a}
.tag.GOLD{background:rgba(245,197,66,.18);color:#f5c542}
.tag.OIL{background:rgba(148,163,184,.2);color:#cbd5e1}
.tag.MARKETS{background:rgba(59,156,255,.18);color:#7cbcff}
.item .ago{font-size:11.5px;color:var(--muted)}
.item .src{font-size:11.5px;color:var(--muted)}
.sep{color:#22d3ee;opacity:.6}
#news-ar{top:38px;height:36px;background:rgba(4,14,20,.9)}
#news-ar .lbl{border-right:none;border-left:1px solid rgba(34,211,238,.35);letter-spacing:0;font-size:14.5px}
#news-ar .lbl i{margin-right:0;margin-left:8px}
#news-ar .track{direction:rtl;animation-name:ticker-ar}
#news-ar .item{font-family:"Segoe UI","Tahoma","Arial",sans-serif;font-size:15px}
#news-ar .item .tag{letter-spacing:0;font-size:11.5px}
#news-kw{top:74px;height:36px;background:rgba(3,16,10,.9);border-bottom-color:rgba(34,197,94,.35)}
#news-kw .lbl{background:rgba(34,197,94,.12);border-right-color:rgba(34,197,94,.35);letter-spacing:2px;
text-shadow:0 0 6px #22c55e,0 0 14px #22c55e}
#news-kw .item{font-family:"Segoe UI","Tahoma","Arial",sans-serif}
.flag{position:relative;width:21px;height:13px;margin-right:8px;flex:none;border-radius:1px;overflow:hidden;
background:linear-gradient(#007a3d 0 33.3%,#fff 33.3% 66.6%,#ce1126 66.6%);box-shadow:0 0 6px rgba(34,197,94,.6)}
.flag::before{content:"";position:absolute;left:0;top:0;width:7px;height:100%;background:#000;
clip-path:polygon(0 0,100% 33.3%,100% 66.6%,0 100%)}
.tag.KUWAIT{background:rgba(34,197,94,.18);color:#4ade80}
.tag.BOURSA{background:rgba(206,17,38,.22);color:#fb7185}
@keyframes ticker-ar{from{transform:translateX(-50%)}to{transform:translateX(0)}}

#clock{position:absolute;bottom:18px;left:0;right:370px;text-align:center;pointer-events:none}
#clock .t{font-size:44px;font-weight:600;font-variant-numeric:tabular-nums;letter-spacing:1px;
color:#e6fdff;text-shadow:0 0 4px #fff,0 0 10px #22d3ee,0 0 20px #22d3ee,0 0 40px #06b6d4,0 0 70px #0891b2}
footer{display:flex;align-items:center;justify-content:space-between;margin-top:auto}
.brand{position:absolute;left:20px;bottom:14px;pointer-events:none;font-size:26px;font-weight:700;letter-spacing:6px;
color:#e6fdff;text-shadow:0 0 4px #fff,0 0 10px #22d3ee,0 0 20px #22d3ee,0 0 40px #06b6d4,0 0 70px #0891b2}
#clock .t span{font-size:20px;margin-left:6px}
#clock .d{font-size:13px;color:#a5f3fc;letter-spacing:1px;text-shadow:0 0 8px #22d3ee,0 1px 8px #000}
.mkt.open .st{color:#22c55e}
.mkt.closed .st{color:#ef4444}
</style></head>
<body>
<canvas id="space"></canvas>
<div id="globe"></div>
<div id="solar"></div>
<div id="news"><div class="lbl"><i></i>NEWS</div><div class="vp"><div class="track" id="ntrack">
<span class="item"><span class="h">Loading latest headlines…</span></span></div></div></div>
<div id="news-ar" dir="rtl"><div class="lbl"><i></i>أخبار</div><div class="vp"><div class="track" id="ntrack-ar">
<span class="item"><span class="h">جارٍ تحميل آخر الأخبار…</span></span></div></div></div>
<div id="news-kw"><div class="lbl"><span class="flag"></span>KUWAIT · الكويت</div><div class="vp"><div class="track" id="ntrack-kw">
<span class="item"><span class="h">Loading Kuwait market news…</span></span></div></div></div>
<div id="sessions"><span class="title">MARKET SESSIONS <small>· Kuwait time</small></span><div id="mkts"></div></div>
<div class="brand">DOS</div>
<div id="styles"></div>
<div id="clock"><div class="t" id="kwt">--:--:--</div><div class="d" id="kwd">KUWAIT</div></div>
<div id="panel">
  <header>
    <span class="title">MARKETS</span>
    <span class="ranges">
      <button data-r="1D" class="on">1D</button><button data-r="1M">1M</button><button data-r="3M">3M</button><button data-r="12M">1Y</button>
    </span>
  </header>
  <div id="cards"></div>
  <footer><span>Live prices by TradingView</span></footer>
</div>

<script src="https://unpkg.com/globe.gl"></script>
<script src="https://unpkg.com/topojson-client@3"></script>
<script src="https://unpkg.com/three@0.147.0/build/three.min.js"></script>
<script src="https://unpkg.com/three@0.147.0/examples/js/controls/OrbitControls.js"></script>
<script>
const SYMBOLS=__SYMBOLS__;
let range='1D';

function build(){
  const box=document.getElementById('cards'); box.innerHTML='';
  SYMBOLS.forEach(s=>{
    const card=document.createElement('div'); card.className='card'; card.title=s.name+' · '+s.symbol;
    const wrap=document.createElement('div'); wrap.className='tradingview-widget-container';
    const inner=document.createElement('div'); inner.className='tradingview-widget-container__widget';
    wrap.appendChild(inner);
    const sc=document.createElement('script');
    sc.type='text/javascript'; sc.async=true;
    sc.src='https://s3.tradingview.com/external-embedding/embed-widget-mini-symbol-overview.js';
    sc.innerHTML=JSON.stringify({
      symbol:s.symbol, width:'100%', height:'100%', locale:'en', dateRange:range,
      colorTheme:'dark', isTransparent:true, autosize:true, largeChartUrl:'', noTimeScale:true
    });
    wrap.appendChild(sc); card.appendChild(wrap); box.appendChild(card);
  });
}
build();

document.querySelectorAll('.ranges button').forEach(b=>b.onclick=()=>{
  document.querySelectorAll('.ranges button').forEach(x=>x.classList.remove('on'));
  b.classList.add('on'); range=b.dataset.r; build();
});

/* ---------- market sessions (local exchange hours, Mon-Fri) ---------- */
// s = trading periods in minutes after local midnight
const MARKETS=[
 {name:'Sydney',  ex:'ASX',  tz:'Australia/Sydney', lat:-33.87,lng:151.21,s:[[600,960]]},
 {name:'Tokyo',   ex:'TSE',  tz:'Asia/Tokyo',       lat:35.68, lng:139.69,s:[[540,690],[750,930]]},
 {name:'China',   ex:'Shanghai',tz:'Asia/Shanghai', lat:31.23, lng:121.47,s:[[570,690],[780,900]]},
 {name:'Kuwait',  ex:'Boursa',tz:'Asia/Kuwait',     lat:29.37, lng:47.98, s:[[540,790]], days:[0,1,2,3,4]},
 {name:'UAE',     ex:'DFM / ADX',tz:'Asia/Dubai',   lat:25.2,  lng:55.27, s:[[600,895]]},
 {name:'KSA',     ex:'Tadawul',tz:'Asia/Riyadh',    lat:24.71, lng:46.68, s:[[600,910]], days:[0,1,2,3,4]},
 {name:'London',  ex:'LSE',  tz:'Europe/London',    lat:51.51, lng:-0.13, s:[[480,990]]},
 {name:'New York',ex:'NYSE', tz:'America/New_York', lat:40.71, lng:-74.0, s:[[570,960]]}];
const DAYS={Sun:0,Mon:1,Tue:2,Wed:3,Thu:4,Fri:5,Sat:6};
const pad=n=>String(n).padStart(2,'0');

function localParts(tz,d){
  const p={};
  new Intl.DateTimeFormat('en-US',{timeZone:tz,weekday:'short',hour:'2-digit',minute:'2-digit',
    second:'2-digit',hourCycle:'h23'}).formatToParts(d).forEach(x=>p[x.type]=x.value);
  return {day:DAYS[p.weekday],h:+p.hour%24,m:+p.minute,s:+p.second};
}
function status(mk,now){
  const L=localParts(mk.tz,now), W=7*1440;
  const cur=L.day*1440+L.h*60+L.m+L.s/60, mod=cur%1440;
  const iv=[]; (mk.days||[1,2,3,4,5]).forEach(d=>mk.s.forEach(([a,b])=>iv.push([d*1440+a,d*1440+b])));
  const open=iv.find(([a,b])=>cur>=a&&cur<b);
  const next=open?open[1]-cur:Math.min(...iv.map(([a])=>((a-cur)%W+W)%W));
  const lunch=!open&&mk.s.length>1&&(mk.days||[1,2,3,4,5]).includes(L.day)&&mod>=mk.s[0][1]&&mod<mk.s[1][0];
  return {open:!!open,next,lunch,time:pad(L.h)+':'+pad(L.m)};
}
function dur(min){
  const t=Math.ceil(min), h=Math.floor(t/60), m=t%60;
  if(h>=24) return Math.floor(h/24)+'d '+(h%24)+'h';
  return h?h+'h '+pad(m)+'m':m+'m';
}
/* ---------- Kuwait time helpers ---------- */
const KW='Asia/Kuwait';
function tzOffset(tz,d){  // minutes ahead of UTC
  const p={};
  new Intl.DateTimeFormat('en-US',{timeZone:tz,year:'numeric',month:'2-digit',day:'2-digit',
    hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(d).forEach(x=>p[x.type]=x.value);
  const u=Date.UTC(+p.year,+p.month-1,+p.day,+p.hour%24,+p.minute);
  return Math.round((u-Math.floor(d.getTime()/60000)*60000)/60000);
}
function fmt12(min){
  min=((Math.round(min)%1440)+1440)%1440;
  const h=Math.floor(min/60), m=min%60;
  return (h%12||12)+':'+pad(m)+' '+(h<12?'AM':'PM');
}
const kwTime=d=>d.toLocaleTimeString('en-US',{timeZone:KW,hour:'numeric',minute:'2-digit',hour12:true});
const kwDay=d=>d.toLocaleDateString('en-US',{timeZone:KW,weekday:'short'});

let lastKey='';
function tick(){
  const now=new Date();
  MARKETS.forEach(mk=>mk.st=status(mk,now));
  document.getElementById('mkts').innerHTML=MARKETS.map(mk=>{
    const st=mk.st, cls=st.open?'open':'closed';
    const shift=tzOffset(KW,now)-tzOffset(mk.tz,now);
    const hours=fmt12(mk.s[0][0]+shift)+' – '+fmt12(mk.s[mk.s.length-1][1]+shift);
    const at=new Date(now.getTime()+st.next*60000);
    const when=(kwDay(at)!==kwDay(now)?kwDay(at)+' ':'')+kwTime(at);
    const txt=st.open?'OPEN · closes '+when+' · in '+dur(st.next)
      :(st.lunch?'LUNCH BREAK':'CLOSED')+' · opens '+when+' · in '+dur(st.next);
    return `<div class="mkt ${cls}"><span class="dot"></span>
      <span class="nm">${mk.name}<small>${mk.ex}</small></span><span class="tm">${hours}</span>
      <span></span><span class="st">${txt}</span></div>`;
  }).join('');

  const t=now.toLocaleTimeString('en-US',{timeZone:KW,hour:'numeric',minute:'2-digit',second:'2-digit',hour12:true});
  const [clk,ampm]=t.split(' ');
  document.getElementById('kwt').innerHTML=clk+'<span>'+ampm+'</span>';
  document.getElementById('kwd').textContent='KUWAIT · '+now.toLocaleDateString('en-US',
    {timeZone:KW,weekday:'long',day:'numeric',month:'long',year:'numeric'}).toUpperCase();
  const key=MARKETS.map(m=>m.st.open?1:0).join('');
  if(globe&&key!==lastKey){
    lastKey=key;
    globe.labelsData([...MARKETS]);
    globe.ringsData(MARKETS.filter(m=>m.st.open));
  }
}
MARKETS.forEach(mk=>mk.st=status(mk,new Date()));

/* ---------- 3D globe ---------- */
const HUBS=MARKETS;
const ARCS=[];
for(let i=0;i<HUBS.length;i++) for(let j=i+1;j<HUBS.length;j++)
  ARCS.push({startLat:HUBS[i].lat,startLng:HUBS[i].lng,endLat:HUBS[j].lat,endLng:HUBS[j].lng});

let globe=null;
// stage = the area that holds the globe / solar system (phone build sets window.STAGE_EL)
function STAGE(){
  const e=window.STAGE_EL;
  if(e){ const r=e.getBoundingClientRect(); return {x:r.left,y:r.top,w:Math.max(200,r.width),h:Math.max(200,r.height)}; }
  return {x:0,y:0,w:Math.max(300,innerWidth-370),h:innerHeight};
}
const IS_MOBILE=!!window.IS_MOBILE;
function sizeGlobe(){ if(globe){ const st=STAGE(); globe.width(st.w).height(st.h); } }
/* ---------- moving universe background ---------- */
(function(){
  const cv=document.getElementById('space'), g=cv.getContext('2d');
  let W=0,H=0,DPR=1;
  function size(){ DPR=Math.min(2,devicePixelRatio||1); W=innerWidth; H=innerHeight;
    cv.width=W*DPR; cv.height=H*DPR; g.setTransform(DPR,0,0,DPR,0,0); }
  size(); addEventListener('resize',size);
  const rnd=(a,b)=>a+Math.random()*(b-a);
  const TINTS=['255,255,255','200,225,255','255,236,200','180,240,255','255,210,240'];

  // 3D star field flying toward you
  const STARS=Array.from({length:IS_MOBILE?700:1400},()=>({x:rnd(-1,1),y:rnd(-1,1),z:rnd(0.05,1),
    c:TINTS[Math.random()*TINTS.length|0],tw:rnd(0,6.28)}));
  const SPEED=0.035;

  // spiral galaxy (behind the globe)
  const ARMS=3, GAL=Array.from({length:IS_MOBILE?2200:4200},()=>{
    const arm=Math.random()*ARMS|0, r=Math.pow(Math.random(),0.6);
    return {r, a:arm*2*Math.PI/ARMS + r*5.2 + rnd(-0.35,0.35)*(1-r*0.5),
      c: r<0.18?'255,230,190':(Math.random()<0.5?'150,190,255':'200,160,255'), s:rnd(0.7,2.0)};
  });

  // nebula clouds
  const NEB=[{h:'120,60,220',x:.18,y:.25,r:.55},{h:'30,120,255',x:.7,y:.7,r:.6},
             {h:'0,200,220',x:.45,y:.85,r:.45},{h:'220,50,160',x:.85,y:.2,r:.4}];

  let meteors=[], last=performance.now(), t=0;
  function frame(now){
    const dt=Math.min(0.05,(now-last)/1000); last=now; t+=dt;
    g.globalCompositeOperation='source-over';
    g.fillStyle='#02030a'; g.fillRect(0,0,W,H);
    g.globalCompositeOperation='lighter';

    NEB.forEach((n,i)=>{
      const x=(n.x+Math.sin(t*0.03+i*1.7)*0.05)*W, y=(n.y+Math.cos(t*0.025+i)*0.05)*H, r=n.r*Math.max(W,H);
      const gr=g.createRadialGradient(x,y,0,x,y,r);
      gr.addColorStop(0,`rgba(${n.h},0.16)`); gr.addColorStop(0.5,`rgba(${n.h},0.05)`); gr.addColorStop(1,`rgba(${n.h},0)`);
      g.fillStyle=gr; g.fillRect(0,0,W,H);
    });

    // galaxy centered behind the globe area
    const ST=STAGE(), gx=ST.x+ST.w/2, gy=ST.y+ST.h/2, R=Math.min(W,H)*0.62, rot=t*0.03;
    const core=g.createRadialGradient(gx,gy,0,gx,gy,R*0.35);
    core.addColorStop(0,'rgba(255,225,180,0.22)'); core.addColorStop(1,'rgba(255,225,180,0)');
    g.fillStyle=core; g.fillRect(gx-R,gy-R,R*2,R*2);
    for(const p of GAL){
      const a=p.a+rot*(1.2-p.r*0.6), rr=p.r*R;
      const x=gx+Math.cos(a)*rr, y=gy+Math.sin(a)*rr*0.42;
      g.fillStyle=`rgba(${p.c},${0.85-p.r*0.45})`; g.fillRect(x,y,p.s,p.s);
    }

    // stars
    const cx=W/2, cy=H/2, f=Math.max(W,H)*0.6;
    for(const s of STARS){
      s.z-=SPEED*dt;
      if(s.z<=0.02){ s.x=rnd(-1,1); s.y=rnd(-1,1); s.z=1; }
      const px=cx+s.x/s.z*f*0.5, py=cy+s.y/s.z*f*0.5;
      if(px<-20||px>W+20||py<-20||py>H+20){ s.z=1; s.x=rnd(-1,1); s.y=rnd(-1,1); continue; }
      const k=1-s.z, sz=0.4+k*2.2, al=Math.min(1,0.25+k*1.1)*(0.75+0.25*Math.sin(t*3+s.tw));
      g.fillStyle=`rgba(${s.c},${al})`;
      g.beginPath(); g.arc(px,py,sz,0,6.283); g.fill();
    }

    // shooting stars
    if(Math.random()<dt*0.35) meteors.push({x:rnd(0,W),y:rnd(0,H*0.5),vx:rnd(-900,-500),vy:rnd(250,450),life:1});
    meteors=meteors.filter(m=>(m.life-=dt*1.2)>0);
    for(const m of meteors){
      m.x+=m.vx*dt; m.y+=m.vy*dt;
      const tx=m.x-m.vx*0.12, ty=m.y-m.vy*0.12;
      const gr=g.createLinearGradient(m.x,m.y,tx,ty);
      gr.addColorStop(0,`rgba(220,250,255,${m.life})`); gr.addColorStop(1,'rgba(220,250,255,0)');
      g.strokeStyle=gr; g.lineWidth=2; g.beginPath(); g.moveTo(m.x,m.y); g.lineTo(tx,ty); g.stroke();
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
})();

/* ---------- 3D solar system ---------- */
const SOLAR=(function(){
  const wrap=document.getElementById('solar');
  let ready=false, on=false, running=false, renderer, scene, camera, controls, last=0;
  const bodies=[], labels=[];
  const W=()=>STAGE().w, H=()=>STAGE().h;
  const hex=h=>[parseInt(h.slice(1,3),16),parseInt(h.slice(3,5),16),parseInt(h.slice(5,7),16)];
  const mix=(a,b,t)=>a.map((v,i)=>Math.round(v+(b[i]-v)*t));

  function tex(w,h,draw){
    const c=document.createElement('canvas'); c.width=w; c.height=h; draw(c.getContext('2d'),w,h);
    const t=new THREE.CanvasTexture(c); t.encoding=THREE.sRGBEncoding; t.anisotropy=4; return t;
  }
  function bands(cols,n,wob){
    const C=cols.map(hex);
    return tex(512,256,(g,w,h)=>{
      for(let y=0;y<h;y++){
        const v=y/h, k=(Math.sin(v*n*Math.PI+Math.sin(v*17)*wob)*0.5+0.5)*(C.length-1);
        const i=Math.min(C.length-2,Math.floor(k)), c=mix(C[i],C[i+1],k-i);
        g.fillStyle=`rgb(${c})`; g.fillRect(0,y,w,1);
      }
      for(let i=0;i<900;i++){
        g.fillStyle=Math.random()<.5?'rgba(255,255,255,.05)':'rgba(0,0,0,.06)';
        g.fillRect(Math.random()*w,Math.random()*h,8+Math.random()*60,1+Math.random()*2);
      }
    });
  }
  function rocky(base,spots){
    return tex(512,256,(g,w,h)=>{
      g.fillStyle=base; g.fillRect(0,0,w,h);
      for(let i=0;i<2200;i++){
        g.fillStyle=spots[i%spots.length]; g.globalAlpha=.06+Math.random()*.12;
        g.beginPath(); g.arc(Math.random()*w,Math.random()*h,1+Math.random()*9,0,6.283); g.fill();
      }
      g.globalAlpha=1;
    });
  }
  function glowTex(rgb){
    return tex(256,256,(g,w)=>{
      const gr=g.createRadialGradient(w/2,w/2,0,w/2,w/2,w/2);
      gr.addColorStop(0,`rgba(${rgb},1)`); gr.addColorStop(.2,`rgba(${rgb},.55)`);
      gr.addColorStop(.5,`rgba(${rgb},.12)`); gr.addColorStop(1,`rgba(${rgb},0)`);
      g.fillStyle=gr; g.fillRect(0,0,w,w);
    });
  }
  function label(text,cls){
    const el=document.createElement('div'); el.className='plabel'+(cls?' '+cls:''); el.textContent=text;
    wrap.appendChild(el); return el;
  }

  const PLANETS=[
    {n:'MERCURY',r:.45,d:9,   y:.24,  t:()=>rocky('#9c9488',['#6f685f','#c4bcae'])},
    {n:'VENUS',  r:.9, d:12.5,y:.62,  t:()=>bands(['#c99a5b','#e8cf9a','#d9b77a'],9,2)},
    {n:'EARTH',  r:1,  d:16.5,y:1,    img:'https://unpkg.com/three-globe/example/img/earth-blue-marble.jpg',moon:true},
    {n:'MARS',   r:.6, d:20.5,y:1.88, t:()=>rocky('#b5512e',['#7f3119','#d9875a'])},
    {n:'JUPITER',r:2.6,d:28,  y:11.86,t:()=>bands(['#a8754f','#e9dcc4','#c9a27c','#f1e6d2','#b98a62'],14,3)},
    {n:'SATURN', r:2.2,d:37,  y:29.46,t:()=>bands(['#c4a66d','#efe0b8','#d8c08f'],12,2),ring:true},
    {n:'URANUS', r:1.5,d:45,  y:84,   t:()=>bands(['#8ad3dc','#b9eef2','#9fe3ea'],6,1),tilt:1.7},
    {n:'NEPTUNE',r:1.45,d:52, y:164.8,t:()=>bands(['#2f49b0','#5b7ff0','#3d5fd8'],7,1.5)}];

  function init(){
    if(typeof THREE==='undefined'){ console.log('three.js not loaded'); return false; }
    renderer=new THREE.WebGLRenderer({antialias:true,alpha:true});
    renderer.setClearColor(0x000000,0); renderer.setPixelRatio(Math.min(2,devicePixelRatio||1));
    renderer.outputEncoding=THREE.sRGBEncoding;
    wrap.appendChild(renderer.domElement);
    scene=new THREE.Scene();
    camera=new THREE.PerspectiveCamera(45,1,0.1,3000);
    if(IS_MOBILE) camera.position.set(0,52,112); else camera.position.set(0,34,74);
    controls=new THREE.OrbitControls(camera,renderer.domElement);
    controls.enableDamping=true; controls.enablePan=false;
    controls.autoRotate=true; controls.autoRotateSpeed=0.35;
    controls.minDistance=10; controls.maxDistance=170;

    scene.add(new THREE.AmbientLight(0xffffff,0.16));
    scene.add(new THREE.PointLight(0xfff2d6,2.1,0,0));

    // sun
    const sun=new THREE.Mesh(new THREE.SphereGeometry(5,64,64),
      new THREE.MeshBasicMaterial({map:rocky('#ffb12e',['#ff7a00','#ffe37a','#ff9500'])}));
    scene.add(sun);
    const glow=new THREE.Sprite(new THREE.SpriteMaterial({map:glowTex('255,170,60'),
      blending:THREE.AdditiveBlending,depthWrite:false,transparent:true}));
    glow.scale.set(30,30,1); scene.add(glow);
    bodies.push({mesh:sun,spin:0.05,label:label('SUN','sun'),r:5});

    const loader=new THREE.TextureLoader();
    PLANETS.forEach(p=>{
      // orbit line
      const pts=[]; for(let i=0;i<=256;i++){ const a=i/256*Math.PI*2; pts.push(new THREE.Vector3(Math.cos(a)*p.d,0,Math.sin(a)*p.d)); }
      scene.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts),
        new THREE.LineBasicMaterial({color:0x22d3ee,transparent:true,opacity:0.18})));

      const orbit=new THREE.Object3D(); scene.add(orbit);
      const holder=new THREE.Object3D(); holder.position.x=p.d; orbit.add(holder);
      holder.rotation.z=p.tilt||0.3;
      let map;
      if(p.img){ map=loader.load(p.img); map.encoding=THREE.sRGBEncoding; } else map=p.t();
      const mesh=new THREE.Mesh(new THREE.SphereGeometry(p.r,48,48),
        new THREE.MeshStandardMaterial({map,roughness:1,metalness:0}));
      holder.add(mesh);

      if(p.ring){
        const inner=p.r*1.3, outer=p.r*2.4, g=new THREE.RingGeometry(inner,outer,128);
        const pos=g.attributes.position, uv=g.attributes.uv, v=new THREE.Vector3();
        for(let i=0;i<pos.count;i++){ v.fromBufferAttribute(pos,i); uv.setXY(i,(v.length()-inner)/(outer-inner),0.5); }
        const rt=tex(512,8,(c,w,h)=>{
          for(let x=0;x<w;x++){ const a=(0.35+0.6*Math.abs(Math.sin(x*0.09)*Math.sin(x*0.023)))*(x<20||x>w-12?0.3:1);
            c.fillStyle=`rgba(${mix([196,166,109],[245,232,200],Math.random()*.6+.2)},${a})`; c.fillRect(x,0,1,h); }
        });
        const ring=new THREE.Mesh(g,new THREE.MeshStandardMaterial({map:rt,side:THREE.DoubleSide,transparent:true,
          roughness:1,metalness:0,depthWrite:false}));
        ring.rotation.x=-Math.PI/2; holder.add(ring);
      }
      let moon=null;
      if(p.moon){
        const mp=new THREE.Object3D(); holder.add(mp);
        const mm=new THREE.Mesh(new THREE.SphereGeometry(0.27,24,24),
          new THREE.MeshStandardMaterial({map:rocky('#a9a9a9',['#7a7a7a','#d0d0d0']),roughness:1}));
        mm.position.x=2; mp.add(mm); moon=mp;
      }
      orbit.rotation.y=Math.random()*Math.PI*2;
      bodies.push({mesh,orbit,moon,spin:0.6/Math.max(.4,p.r),w:0.35/Math.sqrt(p.y),label:label(p.n),r:p.r});
    });
    resize(); addEventListener('resize',resize);
    return true;
  }
  function resize(){
    if(!renderer) return;
    wrap.style.width=W()+'px'; wrap.style.height=H()+'px';
    renderer.setSize(W(),H()); camera.aspect=W()/H(); camera.updateProjectionMatrix();
  }
  const v=new (window.THREE?THREE.Vector3:Object)();
  function loop(now){
    if(!on){ running=false; return; }
    const dt=Math.min(0.05,(now-(last||now))/1000); last=now;
    for(const b of bodies){
      if(b.orbit) b.orbit.rotation.y+=b.w*dt;
      b.mesh.rotation.y+=b.spin*dt;
      if(b.moon) b.moon.rotation.y+=1.6*dt;
    }
    controls.update(); renderer.render(scene,camera);
    const w=W(), h=H();
    for(const b of bodies){
      b.mesh.getWorldPosition(v); v.y+=b.r*1.25; v.project(camera);
      if(v.z>1){ b.label.style.display='none'; continue; }
      b.label.style.display='';
      b.label.style.transform=`translate(${(v.x*.5+.5)*w}px,${(-v.y*.5+.5)*h}px) translate(-50%,-100%)`;
    }
    requestAnimationFrame(loop);
  }
  return {
    show(x){
      on=x; wrap.style.display=x?'block':'none';
      if(x&&!ready) ready=init();
      if(x&&ready&&!running){ running=true; last=0; requestAnimationFrame(loop); }
      return ready;
    }
  };
})();

/* ---------- globe styles ---------- */
const IMG='https://unpkg.com/three-globe/example/img/';
const STYLES={
  solar:{label:'Solar System', solar:true, atmo:'#4f7cff'},
  blue: {label:'Blue Marble', img:'earth-blue-marble.jpg', bump:true, atmo:'#4f7cff'},
  night:{label:'Night Lights',img:'earth-night.jpg',       bump:true, atmo:'#f5b642'},
  dark: {label:'Dark',        img:'earth-dark.jpg',        bump:true, atmo:'#64748b'},
  hex:  {label:'Hex Dots',    color:'#07142b', hex:'#3b9cff',          atmo:'#3b9cff'},
  neon: {label:'Neon',        color:'#020812', neon:'#22d3ee',         atmo:'#22d3ee'}};
let countries=null, currentStyle='solar';
function loadCountries(){
  if(countries) return Promise.resolve(countries);
  return fetch('https://unpkg.com/world-atlas@2/countries-110m.json').then(r=>r.json())
    .then(t=>countries=topojson.feature(t,t.objects.countries).features.filter(f=>f.id!=='010'));
}
function applyStyle(name){
  if(!STYLES[name]) name='solar';
  currentStyle=name;
  const s=STYLES[name];
  document.querySelectorAll('#styles button').forEach(b=>b.classList.toggle('on',b.dataset.s===name));
  const solarOn=!!s.solar && SOLAR.show(true);
  if(!s.solar||!solarOn) SOLAR.show(false);
  document.getElementById('globe').style.visibility=solarOn?'hidden':'visible';
  if(globe){ try{ solarOn?globe.pauseAnimation():globe.resumeAnimation(); }catch(e){} }
  if(s.solar){
    try{ window.pywebview&&window.pywebview.api&&window.pywebview.api.save_style(name); }catch(e){}
    return;
  }
  if(!globe) return;
  const mat=globe.globeMaterial();
  globe.hexPolygonsData([]).polygonsData([]);
  if(s.img){
    mat.color.set('#ffffff');
    globe.globeImageUrl(IMG+s.img).bumpImageUrl(s.bump?IMG+'earth-topology.png':null);
  }else{
    globe.globeImageUrl(null).bumpImageUrl(null);
    mat.color.set(s.color);
    loadCountries().then(cs=>{
      if(currentStyle!==name) return;
      if(s.hex) globe.hexPolygonsData(cs).hexPolygonResolution(3).hexPolygonMargin(0.35)
        .hexPolygonColor(()=>s.hex);
      if(s.neon) globe.polygonsData(cs).polygonAltitude(0.006)
        .polygonCapColor(()=>'rgba(34,211,238,0.06)').polygonSideColor(()=>'rgba(0,0,0,0)')
        .polygonStrokeColor(()=>s.neon);
    }).catch(e=>console.log('countries failed',e));
  }
  globe.atmosphereColor(s.atmo);
  try{ window.pywebview&&window.pywebview.api&&window.pywebview.api.save_style(name); }catch(e){}
}
document.getElementById('styles').innerHTML=Object.entries(STYLES)
  .map(([k,v])=>`<button data-s="${k}">${v.label}</button>`).join('');
document.querySelectorAll('#styles button').forEach(b=>b.onclick=()=>applyStyle(b.dataset.s));

try{
  globe=Globe({rendererConfig:{antialias:true,alpha:true}})(document.getElementById('globe'))
    .globeImageUrl(IMG+'earth-blue-marble.jpg')
    .bumpImageUrl(IMG+'earth-topology.png')
    .backgroundColor('rgba(0,0,0,0)')
    .atmosphereColor('#4f7cff').atmosphereAltitude(0.18)
    .ringsData(HUBS.filter(m=>m.st.open)).ringColor(()=>t=>`rgba(34,197,94,${1-t})`)
    .ringMaxRadius(5).ringPropagationSpeed(2).ringRepeatPeriod(1200)
    .arcsData(ARCS).arcColor(()=>['rgba(79,124,255,.6)','rgba(34,211,238,.6)'])
    .arcDashLength(0.4).arcDashGap(0.25).arcDashAnimateTime(3000).arcStroke(0.4)
    .labelsData(HUBS).labelText(m=>m.name+(m.st.open?' · OPEN':' · CLOSED'))
    .labelSize(1.2).labelDotRadius(0.6).labelResolution(2)
    .labelColor(m=>m.st.open?'#22c55e':'#ef4444');
  globe.controls().autoRotate=true;
  globe.controls().autoRotateSpeed=0.5;
  globe.pointOfView({lat:28,lng:20,altitude:IS_MOBILE?3.1:2.4});
  sizeGlobe(); addEventListener('resize',sizeGlobe);
}catch(e){ console.log('Globe failed to load',e); }
tick(); setInterval(tick,1000);

/* ---------- news tickers (English + Arabic) ---------- */
const esc=t=>String(t).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const TAG_AR={CRYPTO:'عملات رقمية',GOLD:'ذهب',OIL:'نفط',MARKETS:'أسواق',KUWAIT:'الكويت',BOURSA:'البورصة'};
function ago(ts,ar){
  if(!ts) return '';
  const m=Math.max(0,Math.round((Date.now()/1000-ts)/60));
  if(ar) return m<60?'منذ '+m+' د':m<1440?'منذ '+Math.floor(m/60)+' س':'منذ '+Math.floor(m/1440)+' يوم';
  return m<60?m+'m ago':m<1440?Math.floor(m/60)+'h ago':Math.floor(m/1440)+'d ago';
}
function makeTicker(trackId,apiName,ar){
  const tr=document.getElementById(trackId); let list=[];
  function draw(){
    if(!list.length){
      tr.innerHTML='<span class="item"><span class="h">'+(ar?'لا توجد أخبار الآن، ستتم المحاولة مجددًا…':'No headlines right now. Retrying soon…')+'</span></span>';
      return;
    }
    const one=list.map((n,i)=>`<span class="item" data-i="${i}"><span class="tag ${n.tag}">${ar?TAG_AR[n.tag]||n.tag:n.tag}</span>
      <span class="h" dir="auto">${esc(n.title)}</span><span class="src">${esc(n.source)}</span><span class="ago">${ago(n.ts,ar)}</span>
      </span><span class="sep">✦</span>`).join('');
    tr.innerHTML=one+one;
    requestAnimationFrame(()=>{ tr.style.setProperty('--dur',Math.max(40,tr.scrollWidth/2/65)+'s'); });
  }
  tr.addEventListener('click',e=>{
    const it=e.target.closest('.item'); if(!it||it.dataset.i==null) return;
    const n=list[+it.dataset.i]; if(n&&n.link&&window.pywebview) window.pywebview.api.open_link(n.link);
  });
  return function load(){
    if(!window.pywebview||!window.pywebview.api) return;
    window.pywebview.api[apiName]().then(r=>{
      if(r&&r.length){ list=r; draw(); } else if(!list.length) draw();
    }).catch(e=>console.log('news',e));
  };
}
const loadEn=makeTicker('ntrack','get_news',false);
const loadAr=makeTicker('ntrack-ar','get_news_ar',true);
const loadKw=makeTicker('ntrack-kw','get_news_kw',false);
function startNews(){ loadEn(); loadAr(); loadKw(); setInterval(()=>{loadEn();loadAr();loadKw();},5*60*1000); }
if(window.pywebview&&window.pywebview.api) startNews();
else window.addEventListener('pywebviewready',startNews);

function restoreStyle(){
  window.pywebview.api.load_style().then(n=>applyStyle(n||'solar')).catch(()=>applyStyle('solar'));
}
document.querySelectorAll('#styles button')[0].classList.add('on');
if(SOLAR.show(true)) document.getElementById('globe').style.visibility='hidden';
if(window.pywebview&&window.pywebview.api) restoreStyle();
else window.addEventListener('pywebviewready',restoreStyle);
</script>
</body></html>
"""


SETTINGS = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "DOS POWER", "settings.json")


# ---------- news feeds (title, url, default tag) ----------
FEEDS = [
    ("CoinDesk",      "https://www.coindesk.com/arc/outboundfeeds/rss/", "CRYPTO"),
    ("Cointelegraph", "https://cointelegraph.com/rss",                   "CRYPTO"),
    ("OilPrice",      "https://oilprice.com/rss/main",                   "OIL"),
    ("FXStreet",      "https://www.fxstreet.com/rss/news",               "MARKETS"),
    ("Investing.com", "https://www.investing.com/rss/news_11.rss",       "MARKETS"),
    ("Kitco",         "https://www.kitco.com/rss/KitcoNews.xml",         "GOLD"),
]
FEEDS_AR = [
    ("CNN بالعربية",     "https://arabic.cnn.com/api/v1/rss/business/rss.xml", "MARKETS"),
    ("Investing.com",   "https://sa.investing.com/rss/news.rss",              "MARKETS"),
    ("Investing.com",   "https://sa.investing.com/rss/news_11.rss",           "MARKETS"),
    ("Investing.com",   "https://sa.investing.com/rss/news_301.rss",          "CRYPTO"),
    ("سكاي نيوز عربية", "https://www.skynewsarabia.com/rss/business.xml",      "MARKETS"),
    ("العربية",          "https://www.alarabiya.net/feed/rss2/ar/aswaq.xml",   "MARKETS"),
]


def _gnews(q, lang):
    from urllib.parse import quote_plus
    if lang == "ar":
        return "https://news.google.com/rss/search?q=" + quote_plus(q) + "&hl=ar&gl=KW&ceid=KW:ar"
    return "https://news.google.com/rss/search?q=" + quote_plus(q) + "&hl=en-KW&gl=KW&ceid=KW:en"


FEEDS_KW = [
    ("Google News",  _gnews('"Boursa Kuwait" when:7d', "en"),                 "KUWAIT"),
    ("Google News",  _gnews("Kuwait stocks OR Kuwait economy when:7d", "en"), "KUWAIT"),
    ("Google News",  _gnews("بورصة الكويت when:7d", "ar"),                    "KUWAIT"),
    ("Google News",  _gnews("اقتصاد الكويت when:7d", "ar"),                   "KUWAIT"),
    ("Kuwait Times", "https://kuwaittimes.com/category/business/feed/",       "KUWAIT"),
    ("Arab Times",   "https://www.arabtimesonline.com/news/category/business/feed/", "KUWAIT"),
]
NEWS_CACHE_SECONDS = 300
PER_FEED = 8
_news = {}
_news_lock = threading.Lock()


def _tag_for(title, default):
    t = title.lower()
    if re.search(r"بيتكوين|بتكوين|كريبتو|المشفرة|الرقمية|إيثريوم|زيكاش", t):
        return "CRYPTO"
    if re.search(r"ذهب|الذهب|المعادن النفيسة|الفضة", t):
        return "GOLD"
    if re.search(r"نفط|النفط|برنت|الخام|أوبك|البرميل", t):
        return "OIL"
    if re.search(r"bitcoin|btc|zcash|zec|crypto|ether|blockchain|stablecoin", t):
        return "CRYPTO"
    if re.search(r"\bgold\b|bullion|xau|silver|precious", t):
        return "GOLD"
    if re.search(r"\boil\b|crude|brent|wti|opec|barrel|gasoline", t):
        return "OIL"
    return default


def _text(el, *names):
    for n in names:
        x = el.find(n)
        if x is not None:
            if x.text and x.text.strip():
                return x.text.strip()
            if x.get("href"):
                return x.get("href")
    return ""


def parse_feed(data, source, default_tag):
    root = ET.fromstring(data)
    atom = "{http://www.w3.org/2005/Atom}"
    nodes = root.findall(".//item") or root.findall(".//" + atom + "entry")
    out = []
    for it in nodes[:PER_FEED]:
        title = _text(it, "title", atom + "title")
        title = htmllib.unescape(re.sub(r"<[^>]+>", "", title)).strip()
        if not title:
            continue
        link = _text(it, "link", atom + "link")
        src_el = it.find("source")
        src = source
        if src_el is not None and src_el.text and src_el.text.strip():
            src = src_el.text.strip()
            if title.endswith(" - " + src):
                title = title[: -len(" - " + src)].strip()
        when = _text(it, "pubDate", atom + "updated", atom + "published")
        ts = 0
        try:
            ts = parsedate_to_datetime(when).timestamp()
        except Exception:
            try:
                from datetime import datetime
                ts = datetime.fromisoformat(when.replace("Z", "+00:00")).timestamp()
            except Exception:
                ts = 0
        out.append({"title": title, "link": link, "ts": ts,
                    "source": src, "tag": _tag_for(title, default_tag)})
    return out


def fetch_feed(feed):
    source, url, tag = feed
    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) DOS-POWER/1.0",
            "Accept": "application/rss+xml, application/xml, text/xml, */*"})
        with urllib.request.urlopen(req, timeout=10) as r:
            return parse_feed(r.read(), source, tag)
    except Exception:
        return []


def get_all_news(feeds=FEEDS, key="en"):
    with _news_lock:
        c = _news.get(key)
        if c and c["items"] and time.time() - c["t"] < NEWS_CACHE_SECONDS:
            return c["items"]
    results = [None] * len(feeds)

    def run(i, f):
        results[i] = fetch_feed(f)
    threads = [threading.Thread(target=run, args=(i, f), daemon=True) for i, f in enumerate(feeds)]
    for t in threads:
        t.start()
    for t in threads:
        t.join(15)
    items, seen = [], set()
    for lst in results:
        for n in lst or []:
            key = n["title"].lower()[:80]
            if key not in seen:
                seen.add(key)
                items.append(n)
    cutoff = time.time() - 3 * 86400
    items = [n for n in items if not n["ts"] or n["ts"] > cutoff]
    items.sort(key=lambda n: n["ts"], reverse=True)
    items = items[:40]
    with _news_lock:
        if items:
            _news[key] = {"t": time.time(), "items": items}
        return _news.get(key, {}).get("items", [])


class Api:
    def get_news(self):
        return get_all_news(FEEDS, "en")

    def get_news_ar(self):
        return get_all_news(FEEDS_AR, "ar")

    def get_news_kw(self):
        items = get_all_news(FEEDS_KW, "kw")
        for n in items:
            if re.search(r"boursa|bourse|stock|shares|index|بورصة|البورصة|مؤشر|أسهم", n["title"], re.I):
                n["tag"] = "BOURSA"
            elif n["tag"] not in ("CRYPTO", "GOLD", "OIL"):
                n["tag"] = "KUWAIT"
        return items

    def open_link(self, url):
        if isinstance(url, str) and url.startswith(("http://", "https://")):
            webbrowser.open(url)
        return True

    def load_style(self):
        try:
            with open(SETTINGS, encoding="utf-8") as f:
                return json.load(f).get("style", "solar")
        except Exception:
            return "solar"

    def save_style(self, name):
        try:
            os.makedirs(os.path.dirname(SETTINGS), exist_ok=True)
            with open(SETTINGS, "w", encoding="utf-8") as f:
                json.dump({"style": str(name)}, f)
        except Exception:
            pass
        return True


def main():
    symbols = [{"name": n, "symbol": s} for n, s in SYMBOLS]
    html = HTML.replace("__SYMBOLS__", json.dumps(symbols))
    folder = os.path.join(tempfile.gettempdir(), "market_globe")
    os.makedirs(folder, exist_ok=True)
    page = os.path.join(folder, "index.html")
    with open(page, "w", encoding="utf-8") as f:
        f.write(html)

    webview.create_window(
        "DOS POWER",
        url=page,
        js_api=Api(),
        width=1240,
        height=860,
        min_size=(900, 760),
        background_color="#05070d",
    )
    webview.start(http_server=True)  # TradingView widgets need a real http page


if __name__ == "__main__":
    main()
